from tkinter import messagebox

from PIL import Image
from customtkinter import *


def login():
    if usernameEntry.get() == '' or passwordEntry.get() == '':
        messagebox.showerror('Error', 'All fields are required')
    elif usernameEntry.get() == 'senghor' and passwordEntry.get() == '1234':
        messagebox.showinfo('Success', 'Login is successful')
        root.destroy()
        import ems
    else:
        messagebox.showerror('Error', 'wrong credentials')


root = CTk()
root.geometry('930x478')
root.resizable(0,0)
root.title('Login Page')
image = CTkImage(Image.open('bg3.jpeg'), size=(930, 478))
imageLabel = CTkLabel(root, image=image)
imageLabel.place(x=200, y=0)
headingLabel = CTkLabel(root, text='GESTION VISITORS', bg_color='#FAFAFA', font=('Goody Old Style', 20, 'bold'),
                        text_color='dark blue')
headingLabel.place(x=5, y=0)

usernameEntry = CTkEntry(root, placeholder_text='Enter Your Username', width=150)
usernameEntry.place(x=20, y=80)

passwordEntry = CTkEntry(root, placeholder_text='Enter Your Password', width=150, show='*')
passwordEntry.place(x=20, y=130)

loginButton = CTkButton(root, text='Login', cursor='hand2', command=login)
loginButton.place(x=20, y=190)

root.mainloop()
