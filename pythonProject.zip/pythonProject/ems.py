from customtkinter import *
from PIL import Image
from tkinter import ttk
from tkcalendar import *
from datetime import datetime
import re

window = CTk()
window.geometry('930x580')
window.resizable(False, False)
window.title('GESTION VISITORS')
window.configure(fg_color='#161C30')
#logo = CTkImage(Image.open('cover.jpeg'), size=(930, 158))
logo = CTkImage(Image.open('cover.jpeg'), size=(207, 220))
logoLabel = CTkLabel(window, image=logo, text='')
logoLabel.grid(row=0, column=0, columnspan=2)

leftFrame = CTkFrame(window)
leftFrame.grid(row=1, column=0)

nameLabel = CTkLabel(leftFrame, text='Name', font=('arial', 18, 'bold'))
nameLabel.grid(row=0, column=0, padx=30, pady=8)

nameEntry = CTkEntry(leftFrame, font=('arial', 15, 'bold'), width=240)
nameEntry.grid(row=0, column=1)

phoneLabel = CTkLabel(leftFrame, text='Phone', font=('arial', 18, 'bold'))
phoneLabel.grid(row=1, column=0, padx=20, pady=8)

phoneEntry = CTkEntry(leftFrame, font=('arial', 15, 'bold'), width=240)
phoneEntry.grid(row=1, column=1)

genderLabel = CTkLabel(leftFrame, text='Gender', font=('arial', 18, 'bold'))
genderLabel.grid(row=2, column=0, padx=20, pady=8, sticky='w')

gender_options = ['Male', 'Female']
genderBox = CTkComboBox(leftFrame, values=gender_options, width=240, font=('arial', 15, 'bold'))
genderBox.grid(row=2, column=1)

motifLabel = CTkLabel(leftFrame, text='motif', font=('arial', 18, 'bold'))
motifLabel.grid(row=3, column=0, padx=20, pady=8, sticky='w')

motifEntry = CTkEntry(leftFrame, font=('arial', 15, 'bold'), width=240, height=40)
motifEntry.grid(row=3, column=1, padx=20, pady=8)

dateLabel = CTkLabel(leftFrame, text="Date_Visit(JJ/MM/AAAA):", font=('arial', 18, 'bold'))
dateLabel.grid(row=4, column=0, padx=20, pady=8, sticky='w')

'''def pick_date(event):
    global cal, date_window
    date_window=CTkToplevel()
    date_window.grab_set()
    date_window.title('choisi une date')
    date_window.geometry('250x220+590x370')
    cal=calendar(date_window,selectmode='day',date_pattern='mm/dd/yyyy')
    cal.place(x=0,y=0)

    submit_btn=Button(date_window,text='submit',command=grab_date)
    submit_btn.place(x=80,y=190)

def grab_date():
    dateEntry.delete(0,END)
    dateEntry.insert(0,cal.get_date())
    date_window.destroy()

dateLabel=CTkLabel(leftFrame,text='date:',bg_color='#0055fe',fg_color='white',font=('yu gothic ui',18,'bold'))
dateLabel.grid(row=4, column=0, padx=20, pady=8, sticky='w')

dateEntry=CTkEntry(leftFrame,highlightthickness=0,relief=FLAT,bg_color='white',fg_color='#6b6a69',font=('yu gothic ui',18,'bold'))
dateEntry.grid(row=4, column=1)
dateEntry.insert(0,'dd/mm/yyyy')
dateEntry.bind('<1>',pick_date)
'''


def validate_date(new_text):
    date_pattern = r"^\d{2}/\d{2}/\d{4}$"
    return re.match(date_pattern, new_text) is not NONE


dateEntry = CTkEntry(leftFrame, font=('arial', 15, 'bold'), validate='all',
validatecommand=(window.register(validate_date), '%P'), width=240)
dateEntry.grid(row=4, column=1)

rightFrame = CTkFrame(window)
rightFrame.grid(row=1, column=1)

search_options = ['nom', 'phone', 'gender']
searchBox = CTkComboBox(rightFrame, values=search_options, state='readonly')
searchBox.grid(row=0, column=0)
searchBox.set('Search By')

searchEntry = CTkEntry(rightFrame)
searchEntry.grid(row=0, column=1)

searchButton = CTkButton(rightFrame, text='Search', width=100)
searchButton.grid(row=0, column=2)

showallButton = CTkButton(rightFrame, text='Show All', width=100)
showallButton.grid(row=0, column=3, pady=5)

tree = ttk.Treeview(rightFrame, height=13)
tree.grid(row=1, column=0, columnspan=4)

tree['columns'] = ('name', 'phone', 'gender', 'heureDebut', 'heureFin', 'motif')

tree.heading('name', text='name')
tree.heading('phone', text='phone')
tree.heading('gender', text='gender')

tree.heading('heureDebut', text='heureDebut')
tree.heading('heureFin', text='heureFin')
tree.heading('motif', text='motif')

tree.config(show='headings')

tree.column('name', width=80)
tree.column('phone', width=80)
tree.column('gender', width=80)
tree.column('heureDebut', width=95)
tree.column('heureFin', width=85)
tree.column('motif', width=80)

style = ttk.Style()
style.configure('Treeview.Heading', font=('arial', 11, 'bold'))
window.mainloop()
